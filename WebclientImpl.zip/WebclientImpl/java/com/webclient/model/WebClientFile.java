package com.webclient.model;

import org.springframework.stereotype.Component;

@Component
public class WebClientFile {

	private String fileUrlName;

	public WebClientFile() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WebClientFile(String fileUrlName) {
		super();
		this.fileUrlName = fileUrlName;
	}

	public String getFileUrlName() {
		return fileUrlName;
	}

	public void setFileUrlName(String fileUrlName) {
		this.fileUrlName = fileUrlName;
	}

	@Override
	public String toString() {
		return "WebClientFile [fileUrlName=" + fileUrlName + "]";
	}
	
	
}
