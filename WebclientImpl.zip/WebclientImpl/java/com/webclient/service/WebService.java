package com.webclient.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webclient.model.WebClientFile;

import jakarta.servlet.http.HttpSession;
import reactor.core.publisher.Flux;

@Service
public class WebService {

	
	 @Value("${addressservice.base.url}") 
	    private String addressBaseUrl; 
	
	 @Value("${fileservice.base.url}")
	 private String fileServiceUrl;
	 
	private String AuthToken; 
	
	public String getServiceCall()
	{
		WebClient webclient	= WebClient.builder().baseUrl(addressBaseUrl).defaultHeader(HttpHeaders.CONTENT_TYPE,
				  MediaType.APPLICATION_FORM_URLENCODED_VALUE).defaultHeader(HttpHeaders.ACCEPT,MediaType.APPLICATION_JSON_VALUE).defaultHeader(HttpHeaders.ACCEPT_ENCODING,"gzip, deflate, br").defaultHeader(HttpHeaders.CONNECTION,"keep-alive").build(); 
		
		 String grantType = "password";
	        String scope = "openid";
	        String clientSecret = "81fad65b-2cde-430b-926b-feaf07ee36b0";
	        String clientId = "app_suppliers";
	        String username = "mark.r.paul-rolls-royce.com@example.com";
	        String password = "Password@123";
	        
	        webclient.post().body(BodyInserters.fromFormData("grant_type",grantType).with("scope",scope)
	        		.with("client_secret",clientSecret).with("client_id", clientId).with("username", username)
	        		.with("password", password)).retrieve()
	                .bodyToMono(String.class)
	                .doOnSuccess(response -> {
	                    // Handle the response
	                    System.out.println("Request successful!");
	                    System.out.println(response);
	                    ObjectMapper objectMapper = new ObjectMapper();
	        	        try {
							JsonNode jsonNode = objectMapper.readTree(response);
							AuthToken = jsonNode.get("access_token").asText();
							//AuthToken = "Bearer " + AuthToken;
						} catch (JsonMappingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
	                })
	                .doOnError(error -> {
	                    // Handle the error
	                    System.err.println("Request failed!");
	                    error.printStackTrace();
	                })
	                .block();
	         System.out.println(AuthToken);
	         
	        WebClient webclientfile = WebClient.builder().baseUrl(fileServiceUrl).defaultHeader(HttpHeaders.AUTHORIZATION ,"Bearer " + AuthToken).defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
	               .build();
	        
	        String requestBody = "{\"filename\":\"apple_testing_v1.txt\"}";

	        Flux<WebClientFile> productFlux = webclientfile.post().body(BodyInserters.fromValue(requestBody)).retrieve().bodyToFlux(WebClientFile.class);
            
	        productFlux.subscribe(product -> System.out.println(product.getFileUrlName()));
	        
		return "Success";
	}
	
}
