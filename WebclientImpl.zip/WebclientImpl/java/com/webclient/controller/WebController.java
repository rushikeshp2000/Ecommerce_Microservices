package com.webclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.webclient.service.WebService;

@RestController
public class WebController {

	
	@Autowired
	WebService webService;
	
	@GetMapping("/webcall")
	public String getWebClient()
	{
		webService.getServiceCall();
		return "Success";
	}
}
